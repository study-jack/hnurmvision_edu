# YOLO26n-Pose 装甲板检测与四角点定位

基于 YOLO26n-Pose 微调的 RoboMaster 装甲板检测模型，同时输出装甲板类别、边界框和四个角点关键点。

## 数据集

| 项目 | 数值 |
|---|---|
| 训练集 | 5637 张（1 张损坏已由框架跳过，实际 5636） |
| 验证集 | 1409 张 |
| 类别数 | 14（B1–B5、BO、BS、R1–R5、RO、RS） |
| 标签格式 | 每行 13 列：class cx cy w h + 4 个角点 (x,y)，归一化 |
| 关键点 | kpt_shape [4, 2]，顺序为左上、左下、右下、右上 |

## 训练配置

| 参数 | 值 |
|---|---|
| 模型 | yolo26n-pose.pt（2,707,908 参数，6.4 GFLOPs） |
| 输入尺寸 | 640×640 |
| Batch | 16 |
| 轮数 | 100（best epoch 87，未触发早停） |
| 优化器 | AdamW（auto lr=0.000556） |
| 混合精度 | AMP 开启 |
| 数据增强 | HSV、平移、缩放、水平翻转、Mosaic（最后 10 轮关闭） |
| 训练耗时 | 约 77 分钟 |

环境：Ubuntu 22.04.5，RTX 5070 Ti Laptop 12 GB，Python 3.10.12，torch 2.12.1+cu130，ultralytics 8.4.172。

## 验证集指标

最佳权重（epoch 87）：

| 任务 | Precision | Recall | mAP50 | mAP50-95 |
|---|---:|---:|---:|---:|
| 装甲板检测框 | 92.70% | 90.82% | 95.17% | 67.51% |
| 四角点 Pose | 86.03% | 83.13% | 83.05% | 76.31% |

最后一轮（epoch 100）：

| 任务 | Precision | Recall | mAP50 | mAP50-95 |
|---|---:|---:|---:|---:|
| 装甲板检测框 | 94.02% | 90.16% | 95.09% | 67.39% |
| 四角点 Pose | 86.53% | 83.20% | 83.30% | 76.47% |

说明：以上均为验证集指标，项目没有独立测试集。Pose mAP 基于关键点 OKS 评估，与框 IoU mAP 尺度不同，不可直接比较。

## 文件说明

```
model/
  best.pt            最佳权重（epoch 87）
  last.pt            最后一轮权重（epoch 100）
figures/
  results.png        Ultralytics 训练曲线总图
  training_curves_custom.png  自定义 loss / mAP 曲线
  BoxPR_curve.png    Box Precision-Recall
  BoxF1_curve.png    Box F1-置信度
  PosePR_curve.png   Pose Precision-Recall
  PoseF1_curve.png   Pose F1-置信度
  confusion_matrix.png / confusion_matrix_normalized.png
demo/
  20 张验证集推理可视化（含类别与置信度）
```

## 复现

```bash
python3 -m venv .venv-cuda
.venv-cuda/bin/python -m pip install -r requirements-cuda.txt
.venv-cuda/bin/python check_dataset.py
.venv-cuda/bin/python -u train.py --config train_config.yaml
.venv-cuda/bin/python plot_results.py --run-dir runs/pose/<run-name>
.venv-cuda/bin/python predict.py --weights runs/pose/<run-name>/weights/best.pt --source <图片目录>
```

注意：首次运行需要 `yolo26n-pose.pt`，Ultralytics 会从 GitHub 自动下载；网络受限时可手动放置到项目根目录。
